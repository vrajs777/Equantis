import React, { useState, useRef, useEffect } from "react";
import Slider from "react-slick";
import "../assets/css/font-awesome.css";
import "../assets/css/bootstrap.min.css";
import "slick-carousel/slick/slick.css";

import {ReactComponent as Pattern1 }from '../assets/img/pattern1.svg'
import {ReactComponent as Pattern2 }from '../assets/img/pattern2.svg'
import {ReactComponent as Pattern3 }from '../assets/img/pattern3.svg'
import {ReactComponent as Pattern4 }from '../assets/img/pattern4.svg'
import {ReactComponent as Pattern5 }from '../assets/img/pattern5.svg'
import "../styles.css";
import bannerimg from "../assets/img/banner-img1.png";
import storyimg from "../assets/img/circle-img.png";
import ManchesterLogo from "../assets/img/manchester.svg";
import EastLondon from "../assets/img/east-london.svg";
import NiicoLogo from "../assets/img/niico-logo.png";
import NiicoBg from "../assets/img/Niico-bg.svg";
import FeatureBlogImage from "../assets/img/feature-blog-img1.jpg";
import Alistair from "../assets/img/Alistair.jpg";
import GetTouchImg from "../assets/img/get-img.png";
import GetTouchBg from "../assets/img/get-line-img.svg";
import ChallengeImg1 from "../assets/img/ChallengeImg1.png";
import ChallengeImg2 from "../assets/img/ChallengeImg2.png";
import GreenBannerCircle from "../assets/img/GreenBannerCircle.svg";
import exploredottimg from "../assets/img/explore-dott-img.svg";









export default function SliderMain() {
  const [nav1, setNav1] = useState(null);
  const [index, setIndex] = useState(null);
  const [nav2, setNav2] = useState(null);
  const [nav3, setNav3] = useState(null);
  const [nav4, setNav4] = useState(null);
  const [nav5, setNav5] = useState(null);
  const [laoding, setLoading] = useState(false);
  const [data, setData] = useState();
  const [option, setOption] = useState("Your_bussness");
  const slider1 = useRef(null);
  const slider2 = useRef(null);
  const slider3 = useRef(null);
  const slider4 = useRef(null);
  const slider5 = useRef(null);

  useEffect(() => {
    setLoading(true);
    setNav1(slider1.current);
    slider1.current.slickGoTo(0);
    setNav2(slider2.current);
    setNav3(slider3.current);
    setNav4(slider4.current);
    setNav5(slider5.current);
    setIndex(0);
    fetch("https://run.mocky.io/v3/aa4d7762-6fd9-45aa-9ba3-51d89b8a722f")
      .then((response) => {
        return response.json();
      })
      .then((data) => {
        let datas = data[0];

        Object.keys(datas).forEach(function (key) {
          if (key == option) {
            //  console.log(data, key);
            var value = datas[key];
            setData(value);
            setLoading(false);
            return false;
          }
        });
      });
  }, [option]);

  const settings = {
    loop: true,
    infinite: false,
    // autoplay: true,
    dots: true,
    arrows: false,
    // autoplaySpeed: 3000,

    beforeChange: function (currentSlide, nextSlide) {
      // console.log("before change", currentSlide, nextSlide);
    },
    afterChange: function (currentSlide) {
      // console.log("after change", currentSlide);
      setIndex(currentSlide);
    },
  };
  const handleChange = (e) => {
    setOption(e.target.value);
  };
  return (
    <div>
      {/* <select onChange={handleChange} value={option}>
        <option value='Your_bussness'>Your_bussness</option>
        <option value='Heigher_Education'>Heigher_Education</option>
        <option value='MemberShip'>MemberShip</option>
        <option value='Not_for_profit'>Not_for_profit</option>
      </select> */}

      {/* <div style={{ opacity: laoding ? 1 : 0 }}>loading....</div> */}

      <div style={{ opacity: laoding ? 0 : 1 }}>
        {/* <h4> slider</h4> */}

        <Slider asNavFor={nav2} ref={slider1} {...settings} className='banner'>
          <div>
            <div className='banner-section'>
              <div className='TwoCircleImg'>
                <figure>
                  <img src = {GreenBannerCircle} alt="" />
                </figure>
              </div>
              <div className='container'>
                <div className='banner-content'>
                  <div className='row'>
                    <div className='banner-content col-md-7'>
                      <div className='inner-content'>
                        <div className='banner-title'>
                          <h2>Helping Higher Education <span>to improve the student experience</span></h2>
                        </div>
                      </div>
                    </div>
                    <div className='banner-img col-md-5'>
                      <figure>
                        <img src={bannerimg} alt='Banner Image' />
                      </figure>
                    </div>
                  </div>
                  <div class="explore-btn arrow-btn">
                    <a href="#"><span class="arrow"><i class="far fa-arrow-down"></i></span>Discover how we unlock experience potential in Higher Education</a>
                  </div>
                  <div className='pattern-img desktop'>
                    <figure>
                        <Pattern1 />
                    </figure>
                  </div>
                </div>
              </div>
            </div>
          </div>


          <div>
            <div className='banner-section'>
              <div className='TwoCircleImg'>
                  <figure>
                    <img src = {GreenBannerCircle} alt="" />
                  </figure>
                </div>
              <div className='container'>
                <div className='banner-content'>
                  <div className='row'>
                    <div className='banner-content col-md-7'>
                      <div className='inner-content'>
                        <div className='banner-title'>
                          <h2>Helping Higher Education <span>to improve the student experience</span></h2>
                        </div>
                      </div>
                    </div>
                    <div className='banner-img col-md-5'>
                      <figure>
                        <img src={bannerimg} alt='Banner Image' />
                      </figure>
                    </div>
                  </div>
                  <div class="explore-btn arrow-btn">
                    <a href="#"><span class="arrow"><i class="far fa-arrow-down"></i></span>Discover how we unlock experience potential in Higher Education</a>
                  </div>
                  <div className='pattern-img desktop'>
                    <figure>
                        <Pattern1 />
                    </figure>
                  </div>
                </div>
              </div>
            </div>
          </div>


          <div>
            <div className='banner-section'>
              <div className='TwoCircleImg'>
                <figure>
                  <img src = {GreenBannerCircle} alt="" />
                </figure>
              </div>
              <div className='container'>
                <div className='banner-content'>
                  <div className='row'>
                    <div className='banner-content col-md-7'>
                      <div className='inner-content'>
                        <div className='banner-title'>
                          <h2>Helping Higher Education <span>to improve the student experience</span></h2>
                        </div>
                      </div>
                    </div>
                    <div className='banner-img col-md-5'>
                      <figure>
                        <img src={bannerimg} alt='Banner Image' />
                      </figure>
                    </div>
                  </div>
                  <div class="explore-btn arrow-btn">
                    <a href="#"><span class="arrow"><i class="far fa-arrow-down"></i></span>Discover how we unlock experience potential in Higher Education</a>
                  </div>
                  <div className='pattern-img desktop'>
                    <figure>
                        <Pattern1 />
                    </figure>
                  </div>
                </div>
              </div>
            </div>
          </div>


          <div>
            <div className='banner-section'>
              <div className='TwoCircleImg'>
                <figure>
                  <img src = {GreenBannerCircle} alt="" />
                </figure>
              </div>
              <div className='container'>
                <div className='banner-content'>
                  <div className='row'>
                    <div className='banner-content col-md-7'>
                      <div className='inner-content'>
                        <div className='banner-title'>
                          <h2>Helping Higher Education <span>to improve the student experience</span></h2>
                        </div>
                      </div>
                    </div>
                    <div className='banner-img col-md-5'>
                      <figure>
                        <img src={bannerimg} alt='Banner Image' />
                      </figure>
                    </div>
                  </div>
                  <div class="explore-btn arrow-btn">
                    <a href="#"><span class="arrow"><i class="far fa-arrow-down"></i></span>Discover how we unlock experience potential in Higher Education</a>
                  </div>
                  <div className='pattern-img desktop'>
                    <figure>
                        <Pattern1 />
                    </figure>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Slider>

        <div className='title-content-section text-center'>
          <div className='container'>
            <div className="inner-section">
              <h4>Asking the right questions</h4>
              <p>We understand your role is difficult. Finding the appropriate answers and translating those findings into useful actions solve your problems or challenges.</p>
            </div>
          </div>
        </div>

        {/* {console.log(
            data ? data.Yellow.map((i, el) => console.log(i, el)) : "loading "
          )} */}

        <Slider
          infinite={false}
          arrows={false}
          asNavFor={nav3}
          ref={slider2}
          slidesToShow={1}
          swipeToSlide={false}
          draggable={false}
          // focusOnSelect={true}
          className='firstsection'>
          <div>
            <div className='challenges-section'>
              <div className='container'>
                <div className='challenge-blocks'>
                  <div className='row'>
                    <div className='single-challenge-blog col-md-6'>
                      <div className='blog-img' style = {{background: '#EAFFF5'}}>
                        <figure>
                          <img src = {ChallengeImg1} alt='' />
                        </figure>
                      </div>
                      <div className='blog-content'>
                        <div className='inner-blog-content'>
                          <span className='challenge-tag'>Challenge we solved - Tag</span>
                          <h3>Automating the HE process for MMU</h3>
                          <div class="arrow-btn">
                            <a href="#">Discover more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className='single-challenge-blog col-md-6'>
                      <div className='blog-img' style = {{background: '#F0F1F3'}}>
                        <figure>
                          <img src = {ChallengeImg2} alt='' />
                        </figure>
                      </div>
                      <div className='blog-content'>
                        <div className='inner-blog-content'>
                          <span className='challenge-tag'>Challenge we solved - Tag</span>
                          <h3>Automating the HE process for MMU</h3>
                          <div class="arrow-btn">
                            <a href="#">Discover more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="know-more-section">
                    <div class="inner-blk text-center">
                      <h5>Solving Higher Education challenges</h5>
                      <div class="btn-blk yellow-bg">
                        <a href="#" class="cta-btn">Take me to more challenges</a> 
                      </div>
                    </div>
                </div>
              </div>
              <div className='pattern-img desktop'>
                <figure>
                  <Pattern4 />
                </figure>
              </div>
            </div>
          </div>

          <div>
            <div className='challenges-section'>
              <div className='container'>
                <div className='challenge-blocks'>
                  <div className='row'>
                    <div className='single-challenge-blog col-md-6'>
                      <div className='blog-img' style = {{background: '#EAFFF5'}}>
                        <figure>
                          <img src = {ChallengeImg1} alt='' />
                        </figure>
                      </div>
                      <div className='blog-content'>
                        <div className='inner-blog-content'>
                          <span className='challenge-tag'>Challenge we solved - Tag</span>
                          <h3>Automating the HE process for MMU</h3>
                          <div class="arrow-btn">
                            <a href="#">Discover more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className='single-challenge-blog col-md-6'>
                      <div className='blog-img' style = {{background: '#F0F1F3'}}>
                        <figure>
                          <img src = {ChallengeImg2} alt='' />
                        </figure>
                      </div>
                      <div className='blog-content'>
                        <div className='inner-blog-content'>
                          <span className='challenge-tag'>Challenge we solved - Tag</span>
                          <h3>Automating the HE process for MMU</h3>
                          <div class="arrow-btn">
                            <a href="#">Discover more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="know-more-section">
                    <div class="inner-blk text-center">
                      <h5>Solving Higher Education challenges</h5>
                      <div class="btn-blk yellow-bg">
                        <a href="#" class="cta-btn">Take me to more challenges</a> 
                      </div>
                    </div>
                </div>
              </div>
              <div className='pattern-img desktop'>
                <figure>
                  <Pattern4 />
                </figure>
              </div>
            </div>
          </div>

          <div>
            <div className='challenges-section'>
              <div className='container'>
                <div className='challenge-blocks'>
                  <div className='row'>
                    <div className='single-challenge-blog col-md-6'>
                      <div className='blog-img' style = {{background: '#EAFFF5'}}>
                        <figure>
                          <img src = {ChallengeImg1} alt='' />
                        </figure>
                      </div>
                      <div className='blog-content'>
                        <div className='inner-blog-content'>
                          <span className='challenge-tag'>Challenge we solved - Tag</span>
                          <h3>Automating the HE process for MMU</h3>
                          <div class="arrow-btn">
                            <a href="#">Discover more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className='single-challenge-blog col-md-6'>
                      <div className='blog-img' style = {{background: '#F0F1F3'}}>
                        <figure>
                          <img src = {ChallengeImg2} alt='' />
                        </figure>
                      </div>
                      <div className='blog-content'>
                        <div className='inner-blog-content'>
                          <span className='challenge-tag'>Challenge we solved - Tag</span>
                          <h3>Automating the HE process for MMU</h3>
                          <div class="arrow-btn">
                            <a href="#">Discover more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="know-more-section">
                    <div class="inner-blk text-center">
                      <h5>Solving Higher Education challenges</h5>
                      <div class="btn-blk yellow-bg">
                        <a href="#" class="cta-btn">Take me to more challenges</a> 
                      </div>
                    </div>
                </div>
              </div>
              <div className='pattern-img desktop'>
                <figure>
                  <Pattern4 />
                </figure>
              </div>
            </div>
          </div>

          <div>
            <div className='challenges-section'>
              <div className='container'>
                <div className='challenge-blocks'>
                  <div className='row'>
                    <div className='single-challenge-blog col-md-6'>
                      <div className='blog-img' style = {{background: '#EAFFF5'}}>
                        <figure>
                          <img src = {ChallengeImg1} alt='' />
                        </figure>
                      </div>
                      <div className='blog-content'>
                        <div className='inner-blog-content'>
                          <span className='challenge-tag'>Challenge we solved - Tag</span>
                          <h3>Automating the HE process for MMU</h3>
                          <div class="arrow-btn">
                            <a href="#">Discover more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className='single-challenge-blog col-md-6'>
                      <div className='blog-img' style = {{background: '#F0F1F3'}}>
                        <figure>
                          <img src = {ChallengeImg2} alt='' />
                        </figure>
                      </div>
                      <div className='blog-content'>
                        <div className='inner-blog-content'>
                          <span className='challenge-tag'>Challenge we solved - Tag</span>
                          <h3>Automating the HE process for MMU</h3>
                          <div class="arrow-btn">
                            <a href="#">Discover more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="know-more-section">
                    <div class="inner-blk text-center">
                      <h5>Solving Higher Education challenges</h5>
                      <div class="btn-blk yellow-bg">
                        <a href="#" class="cta-btn">Take me to more challenges</a> 
                      </div>
                    </div>
                </div>
              </div>
              <div className='pattern-img desktop'>
                <figure>
                  <Pattern4 />
                </figure>
              </div>
            </div>
          </div>
          {/* {data.map((i, el) => {
              // console.log(index, "index", el);
              if (index === el) {
                return (
                  <div>
                    <h2>{i.index}</h2>
                    <h2>{i.index}</h2>
                  </div>
                );
              } else {
                return (
                  <div>
                    <h2>data</h2>
                    <h2>data</h2>
                  </div>
                );
              }
            })} */}
        </Slider>

        <Slider
          infinite={false}
          arrows={false}
          asNavFor={nav4}
          ref={slider3}
          slidesToShow={1}
          swipeToSlide={false}
          draggable={false}
          // focusOnSelect={true}
        >
       <div>
         <div className='circle-story-section'>
          <div className='circle-blk-section'>
            <div className='inner-circle-blk'>
              <div className="container">
                <div className="inner-blk">
                  <div className="row">
                    <div className="content-blk col-md-6">
                      <div className="inner-content-blk">
                        <span className="education-row">Higher Education Success Story</span>  
                        <h3>Outcome title here over two lines</h3>
                        <p>A sentence about the solution and sector goes here…</p>
                        <div className="arrow-btn">
                          <a href="#">Discover more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
                        </div>
                      </div>                    
                    </div>
                    <div className="img-blk col-md-6">
                      <div className='inner-img-blk'>
                        <div className='main-img'>
                          <figure>
                            <img src= {storyimg} alt="Story Image" />
                          </figure>
                        </div>
                        <div className='logo-img'>
                          <figure>
                            <img src = {ManchesterLogo} alt="manchester" />
                          </figure>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="story-blk">
            <div className="container">
              <div className='inner-story-blk'>
                <div className='row'>
                  <div className='single-story col-md-6'>
                    <div className="inner-single-story">
                      <div className='content-blk'>
                        <div className='inner-content-blk'>
                          <span className='education-row'>Higher Education Success Story</span>
                          <h4>Success Story title here over two lines or more</h4>
                          <div className="arrow-btn">
                            <a href="#">Discover more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
                          </div>
                        </div>
                      </div>
                      <div className='logo-blk'>
                        <figure>
                          <img src = {ManchesterLogo} alt='manchester' />
                        </figure>
                      </div>
                    </div>
                  </div>

                  <div className='single-story col-md-6'>
                    <div className="inner-single-story">
                      <div className='content-blk'>
                        <div className='inner-content-blk'>
                          <span className='education-row'>Higher Education Success Story</span>
                          <h4>Success Story title here over two lines or more</h4>
                          <div className="arrow-btn">
                            <a href="#">Discover more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
                          </div>
                        </div>
                      </div>
                      <div className='logo-blk'>
                        <figure>
                          <img src = {EastLondon} alt='manchester' />
                        </figure>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className='pattern-img desktop'>
            <figure>
              <Pattern2 />
            </figure>
          </div>
         </div>
       </div>
        
        
       <div>
         <div className='circle-story-section'>
          <div className='circle-blk-section'>
            <div className='inner-circle-blk'>
              <div className="container">
                <div className="inner-blk">
                  <div className="row">
                    <div className="content-blk col-md-6">
                      <div className="inner-content-blk">
                        <span className="education-row">Higher Education Success Story</span>  
                        <h3>Outcome title here over two lines</h3>
                        <p>A sentence about the solution and sector goes here…</p>
                        <div className="arrow-btn">
                          <a href="#">Discover more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
                        </div>
                      </div>                    
                    </div>
                    <div className="img-blk col-md-6">
                      <div className='inner-img-blk'>
                        <div className='main-img'>
                          <figure>
                            <img src= {storyimg} alt="Story Image" />
                          </figure>
                        </div>
                        <div className='logo-img'>
                          <figure>
                            <img src = {ManchesterLogo} alt="manchester" />
                          </figure>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="story-blk">
            <div className="container">
              <div className='inner-story-blk'>
                <div className='row'>
                  <div className='single-story col-md-6'>
                    <div className="inner-single-story">
                      <div className='content-blk'>
                        <div className='inner-content-blk'>
                          <span className='education-row'>Higher Education Success Story</span>
                          <h4>Success Story title here over two lines or more</h4>
                          <div className="arrow-btn">
                            <a href="#">Discover more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
                          </div>
                        </div>
                      </div>
                      <div className='logo-blk'>
                        <figure>
                          <img src = {ManchesterLogo} alt='manchester' />
                        </figure>
                      </div>
                    </div>
                  </div>

                  <div className='single-story col-md-6'>
                    <div className="inner-single-story">
                      <div className='content-blk'>
                        <div className='inner-content-blk'>
                          <span className='education-row'>Higher Education Success Story</span>
                          <h4>Success Story title here over two lines or more</h4>
                          <div className="arrow-btn">
                            <a href="#">Discover more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
                          </div>
                        </div>
                      </div>
                      <div className='logo-blk'>
                        <figure>
                          <img src = {EastLondon} alt='manchester' />
                        </figure>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className='pattern-img desktop'>
            <figure>
              <Pattern2 />
            </figure>
          </div>
         </div>
       </div>
       
       

       <div>
         <div className='circle-story-section'>
          <div className='circle-blk-section'>
            <div className='inner-circle-blk'>
              <div className="container">
                <div className="inner-blk">
                  <div className="row">
                    <div className="content-blk col-md-6">
                      <div className="inner-content-blk">
                        <span className="education-row">Higher Education Success Story</span>  
                        <h3>Outcome title here over two lines</h3>
                        <p>A sentence about the solution and sector goes here…</p>
                        <div className="arrow-btn">
                          <a href="#">Discover more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
                        </div>
                      </div>                    
                    </div>
                    <div className="img-blk col-md-6">
                      <div className='inner-img-blk'>
                        <div className='main-img'>
                          <figure>
                            <img src= {storyimg} alt="Story Image" />
                          </figure>
                        </div>
                        <div className='logo-img'>
                          <figure>
                            <img src = {ManchesterLogo} alt="manchester" />
                          </figure>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="story-blk">
            <div className="container">
              <div className='inner-story-blk'>
                <div className='row'>
                  <div className='single-story col-md-6'>
                    <div className="inner-single-story">
                      <div className='content-blk'>
                        <div className='inner-content-blk'>
                          <span className='education-row'>Higher Education Success Story</span>
                          <h4>Success Story title here over two lines or more</h4>
                          <div className="arrow-btn">
                            <a href="#">Discover more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
                          </div>
                        </div>
                      </div>
                      <div className='logo-blk'>
                        <figure>
                          <img src = {ManchesterLogo} alt='manchester' />
                        </figure>
                      </div>
                    </div>
                  </div>

                  <div className='single-story col-md-6'>
                    <div className="inner-single-story">
                      <div className='content-blk'>
                        <div className='inner-content-blk'>
                          <span className='education-row'>Higher Education Success Story</span>
                          <h4>Success Story title here over two lines or more</h4>
                          <div className="arrow-btn">
                            <a href="#">Discover more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
                          </div>
                        </div>
                      </div>
                      <div className='logo-blk'>
                        <figure>
                          <img src = {EastLondon} alt='manchester' />
                        </figure>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className='pattern-img desktop'>
            <figure>
              <Pattern2 />
            </figure>
          </div>
         </div>
        </div>
         
         

       <div>
         <div className='circle-story-section'>
          <div className='circle-blk-section'>
            <div className='inner-circle-blk'>
              <div className="container">
                <div className="inner-blk">
                  <div className="row">
                    <div className="content-blk col-md-6">
                      <div className="inner-content-blk">
                        <span className="education-row">Higher Education Success Story</span>  
                        <h3>Outcome title here over two lines</h3>
                        <p>A sentence about the solution and sector goes here…</p>
                        <div className="arrow-btn">
                          <a href="#">Discover more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
                        </div>
                      </div>                    
                    </div>
                    <div className="img-blk col-md-6">
                      <div className='inner-img-blk'>
                        <div className='main-img'>
                          <figure>
                            <img src= {storyimg} alt="Story Image" />
                          </figure>
                        </div>
                        <div className='logo-img'>
                          <figure>
                            <img src = {ManchesterLogo} alt="manchester" />
                          </figure>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="story-blk">
            <div className="container">
              <div className='inner-story-blk'>
                <div className='row'>
                  <div className='single-story col-md-6'>
                    <div className="inner-single-story">
                      <div className='content-blk'>
                        <div className='inner-content-blk'>
                          <span className='education-row'>Higher Education Success Story</span>
                          <h4>Success Story title here over two lines or more</h4>
                          <div className="arrow-btn">
                            <a href="#">Discover more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
                          </div>
                        </div>
                      </div>
                      <div className='logo-blk'>
                        <figure>
                          <img src = {ManchesterLogo} alt='manchester' />
                        </figure>
                      </div>
                    </div>
                  </div>

                  <div className='single-story col-md-6'>
                    <div className="inner-single-story">
                      <div className='content-blk'>
                        <div className='inner-content-blk'>
                          <span className='education-row'>Higher Education Success Story</span>
                          <h4>Success Story title here over two lines or more</h4>
                          <div className="arrow-btn">
                            <a href="#">Discover more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
                          </div>
                        </div>
                      </div>
                      <div className='logo-blk'>
                        <figure>
                          <img src = {EastLondon} alt='manchester' />
                        </figure>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className='pattern-img desktop'>
            <figure>
              <Pattern2 />
            </figure>
          </div>
         </div>
       </div>
        </Slider>

        <Slider
          infinite={false}
          arrows={false}
          asNavFor={nav5}
          ref={slider4}
          slidesToShow={1}
          swipeToSlide={false}
          draggable={false}
          // focusOnSelect={true}
        >
          <div>
            <div className='premium-product-section'>
              <div className='inner-premium-product' style = {{background: '#36FF9C'}}>
                <div className='container'>
                  <div className='inner-content'>
                    <div className='row'>
                      <div className='content-blk col-md-6'>
                        <div className='inner-content-blk'>
                          <span>Premium product</span>
                          <h2>Introducing Niico Our intelligent automated…</h2>
                          <div class="btn-blk">
                            <a href="#" class="cta-btn">Learn more</a>
                          </div>
                        </div>
                      </div>
                      <div className='img-blk col-md-6'>
                        <div className='inner-img-blk' style = {{background: `url(${NiicoBg})` }}>
                          <figure>
                            <img src = {NiicoLogo} alt='Niico' />
                          </figure>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='pattern-img desktop'>
                <figure>
                  <Pattern3 />
                </figure>
              </div>
            </div>
          </div>

          <div>
            <div className='premium-product-section'>
              <div className='inner-premium-product' style = {{background: '#36FF9C'}}>
                <div className='container'>
                  <div className='inner-content'>
                    <div className='row'>
                      <div className='content-blk col-md-6'>
                        <div className='inner-content-blk'>
                          <span>Premium product</span>
                          <h2>Introducing Niico Our intelligent automated…</h2>
                          <div class="btn-blk">
                            <a href="#" class="cta-btn">Learn more</a>
                          </div>
                        </div>
                      </div>
                      <div className='img-blk col-md-6'>
                        <div className='inner-img-blk' style = {{background: `url(${NiicoBg})` }}>
                          <figure>
                            <img src = {NiicoLogo} alt='Niico' />
                          </figure>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='pattern-img desktop'>
                <figure>
                  <Pattern3 />
                </figure>
              </div>
            </div>
          </div>

          <div>
            <div className='premium-product-section'>
              <div className='inner-premium-product' style = {{background: '#36FF9C'}}>
                <div className='container'>
                  <div className='inner-content'>
                    <div className='row'>
                      <div className='content-blk col-md-6'>
                        <div className='inner-content-blk'>
                          <span>Premium product</span>
                          <h2>Introducing Niico Our intelligent automated…</h2>
                          <div class="btn-blk">
                            <a href="#" class="cta-btn">Learn more</a>
                          </div>
                        </div>
                      </div>
                      <div className='img-blk col-md-6'>
                        <div className='inner-img-blk' style = {{background: `url(${NiicoBg})` }}>
                          <figure>
                            <img src = {NiicoLogo} alt='Niico' />
                          </figure>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='pattern-img desktop'>
                <figure>
                  <Pattern3 />
                </figure>
              </div>
            </div>
          </div>

          <div>
            <div className='premium-product-section'>
              <div className='inner-premium-product' style = {{background: '#36FF9C'}}>
                <div className='container'>
                  <div className='inner-content'>
                    <div className='row'>
                      <div className='content-blk col-md-6'>
                        <div className='inner-content-blk'>
                          <span>Premium product</span>
                          <h2>Introducing Niico Our intelligent automated…</h2>
                          <div class="btn-blk">
                            <a href="#" class="cta-btn">Learn more</a>
                          </div>
                        </div>
                      </div>
                      <div className='img-blk col-md-6'>
                        <div className='inner-img-blk' style = {{background: `url(${NiicoBg})` }}>
                          <figure>
                            <img src = {NiicoLogo} alt='Niico' />
                          </figure>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='pattern-img desktop'>
                <figure>
                  <Pattern3 />
                </figure>
              </div>
            </div>
          </div>
        </Slider>

        <Slider
          infinite={false}
          arrows={false}
          asNavFor={nav1}
          ref={slider5}
          slidesToShow={1}
          swipeToSlide={false}
          draggable={false}
          // focusOnSelect={true}
        >
          <div>
            <div className='thinklab-blog'>
              <div className="container">
                <div className="section-title">
                  <div class="dot-img desktop">
                    <figure>
                      <img src= {exploredottimg} />
                    </figure>
                  </div>
                  <h2>Our latest Thinklab Higher Education insight…</h2>
                </div>
                <div className='blog-blk'>
                  <div class="single-blog">
											<div class="inner-single-blog">
												<div class="blog-img">
													<div class="inner-blog-img">
														<figure>
															<img src={FeatureBlogImage} alt='Blog Image' />
														</figure>
														<span class="blog-cat">Thought Piece</span>
													</div>
												</div>

												<div class="blog-content">
													<div class="inner-blog-content">
														<h4>Featured Thought Piece Title here relevant to Higher Education</h4>
														<p>A descriptive sentence to support here the article title here. A descriptive sentence to support here the article title here. A descriptive sentence to support here the article title here…</p>
														<div class="blog-writer">
															<div class="img">
																<figure>
																	<img src={Alistair} alt='Alistair' />
																</figure>
															</div>
															<h6>Alistair Sergeant</h6>
														</div>
														<div class="arrow-btn">
															<a href="#">Read more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
														</div>
													</div>
												</div>
											</div>
										</div>
                </div>
                <div className='more-thinkable btn-blk yellow-bg text-center'>
                  <a href="#" className='cta-btn '>More of our Thinklab insights</a>
                </div>
              </div>
              <div className='pattern-img desktop'>
                <figure>
                  <Pattern4 />
                </figure>
              </div>
            </div>
          </div>


          <div>
            <div className='thinklab-blog'>
              <div className="container">
                <div className="section-title">
                  <h2>Our latest Thinklab Higher Education insight…</h2>
                </div>
                <div className='blog-blk'>
                  <div class="single-blog">
											<div class="inner-single-blog">
												<div class="blog-img">
													<div class="inner-blog-img">
														<figure>
															<img src={FeatureBlogImage} alt='Blog Image' />
														</figure>
														<span class="blog-cat">Thought Piece</span>
													</div>
												</div>

												<div class="blog-content">
													<div class="inner-blog-content">
														<h4>Featured Thought Piece Title here relevant to Higher Education</h4>
														<p>A descriptive sentence to support here the article title here. A descriptive sentence to support here the article title here. A descriptive sentence to support here the article title here…</p>
														<div class="blog-writer">
															<div class="img">
																<figure>
																	<img src={Alistair} alt='Alistair' />
																</figure>
															</div>
															<h6>Alistair Sergeant</h6>
														</div>
														<div class="arrow-btn">
															<a href="#">Read more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
														</div>
													</div>
												</div>
											</div>
										</div>
                </div>
                <div className='more-thinkable btn-blk yellow-bg text-center'>
                  <a href="#" className='cta-btn '>More of our Thinklab insights</a>
                </div>
              </div>
              <div className='pattern-img desktop'>
                <figure>
                  <Pattern4 />
                </figure>
              </div>
            </div>
          </div>


          <div>
            <div className='thinklab-blog'>
              <div className="container">
                <div className="section-title">
                  <h2>Our latest Thinklab Higher Education insight…</h2>
                </div>
                <div className='blog-blk'>
                  <div class="single-blog">
											<div class="inner-single-blog">
												<div class="blog-img">
													<div class="inner-blog-img">
														<figure>
															<img src={FeatureBlogImage} alt='Blog Image' />
														</figure>
														<span class="blog-cat">Thought Piece</span>
													</div>
												</div>

												<div class="blog-content">
													<div class="inner-blog-content">
														<h4>Featured Thought Piece Title here relevant to Higher Education</h4>
														<p>A descriptive sentence to support here the article title here. A descriptive sentence to support here the article title here. A descriptive sentence to support here the article title here…</p>
														<div class="blog-writer">
															<div class="img">
																<figure>
																	<img src={Alistair} alt='Alistair' />
																</figure>
															</div>
															<h6>Alistair Sergeant</h6>
														</div>
														<div class="arrow-btn">
															<a href="#">Read more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
														</div>
													</div>
												</div>
											</div>
										</div>
                </div>
                <div className='more-thinkable btn-blk yellow-bg text-center'>
                  <a href="#" className='cta-btn '>More of our Thinklab insights</a>
                </div>
              </div>
              <div className='pattern-img desktop'>
                <figure>
                  <Pattern4 />
                </figure>
              </div>
            </div>
          </div>


          <div>
            <div className='thinklab-blog'>
              <div className="container">
                <div className="section-title">
                  <h2>Our latest Thinklab Higher Education insight…</h2>
                </div>
                <div className='blog-blk'>
                  <div class="single-blog">
											<div class="inner-single-blog">
												<div class="blog-img">
													<div class="inner-blog-img">
														<figure>
															<img src={FeatureBlogImage} alt='Blog Image' />
														</figure>
														<span class="blog-cat">Thought Piece</span>
													</div>
												</div>

												<div class="blog-content">
													<div class="inner-blog-content">
														<h4>Featured Thought Piece Title here relevant to Higher Education</h4>
														<p>A descriptive sentence to support here the article title here. A descriptive sentence to support here the article title here. A descriptive sentence to support here the article title here…</p>
														<div class="blog-writer">
															<div class="img">
																<figure>
																	<img src={Alistair} alt='Alistair' />
																</figure>
															</div>
															<h6>Alistair Sergeant</h6>
														</div>
														<div class="arrow-btn">
															<a href="#">Read more <span class="arrow"><i class="far fa-arrow-right"></i></span></a>
														</div>
													</div>
												</div>
											</div>
										</div>
                </div>
                <div className='more-thinkable btn-blk yellow-bg text-center'>
                  <a href="#" className='cta-btn '>More of our Thinklab insights</a>
                </div>
              </div>
              <div className='pattern-img desktop'>
                <figure>
                  <Pattern4 />
                </figure>
              </div>
            </div>
          </div>
        </Slider>

        <section class="logo-wrap-section">
				<div class="inner-logo-wrap-section">
					<div class="container">
						<div class="row">
							<div class="section-heading col-md-6">
								<h3>We’ve enabled high profile organisations in the sector </h3>
							</div>
							<div class="logo-blk col-md-6">
								<div class="inner-logo-blk">
									<div class="single-logo">
										<figure>
											<img src={ManchesterLogo} />
										</figure>
									</div>
                  <div class="single-logo">
										<figure>
											<img src={EastLondon} />
										</figure>
									</div>
                  <div class="single-logo">
										<figure>
											<img src={EastLondon} />
										</figure>
									</div>
                  <div class="single-logo">
										<figure>
											<img src={ManchesterLogo} />
										</figure>
									</div>
                  <div class="single-logo">
										<figure>
											<img src={ManchesterLogo} />
										</figure>
									</div>

									
									
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="pattern-img desktop">
					<figure>
						<Pattern5 />
					</figure>
				</div>
			</section>
      <section className='get-in-touch'>
          <div className='container'>
            <div className='inner-get-blk' style = {{background: `#262D52 url(${GetTouchBg})`}}>
              <div className='row'>
                <div className='content-blk col-md-8'>
                  <div className='inner-content-blk'>
                    <h2>Contact an expert</h2>
                    <p>Get in touch directly with a consultant - We’d love to discuss how we can help you achieve you project goals.</p>
                    <div className='btn-blk'>
                      <a href="#" className='cta-btn'>Get in touch</a>
                    </div>
                  </div>
                </div>
                <div className='img-blk col-md-4'>
                  <div className='inner-img-blk'>
                    <figure>
                      <img src = {GetTouchImg} alt='' />
                    </figure>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </section>
      </div>
    </div>
  );
}
